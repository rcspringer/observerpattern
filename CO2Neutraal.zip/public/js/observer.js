class Observer {

    constructor(model) {
        this.model = model;
    }

    update() {
        console.log("Model is geupdated!");
    }
}
