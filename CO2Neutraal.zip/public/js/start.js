window.onload = loadApp;

function loadApp() {
    controller = new Controller();
}